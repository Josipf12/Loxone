package com.bwssystems.HABridge.api;

public class UserCreateResponse {
	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
