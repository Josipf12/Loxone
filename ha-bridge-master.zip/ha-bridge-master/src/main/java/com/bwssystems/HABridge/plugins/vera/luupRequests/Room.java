package com.bwssystems.HABridge.plugins.vera.luupRequests;

public class Room {	
	private String name;
	private String id;
	private String section;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
}
