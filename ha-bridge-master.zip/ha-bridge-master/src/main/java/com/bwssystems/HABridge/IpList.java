package com.bwssystems.HABridge;

import java.util.List;

public class IpList {
	private List<NamedIP> devices;

	public List<NamedIP> getDevices() {
		return devices;
	}

	public void setDevices(List<NamedIP> devices) {
		this.devices = devices;
	}

}
