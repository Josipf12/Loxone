package com.bwssystems.HABridge.api;

public class SuccessUserResponse {
	private UserCreateResponse success;

	public UserCreateResponse getSuccess() {
		return success;
	}

	public void setSuccess(UserCreateResponse success) {
		this.success = success;
	}
}
