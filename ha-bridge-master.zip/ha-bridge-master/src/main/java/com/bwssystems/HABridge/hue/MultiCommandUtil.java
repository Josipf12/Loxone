package com.bwssystems.HABridge.hue;

public class MultiCommandUtil {
	private Integer setCount;
	private Integer theDelay;
	private Integer delayDefault;

	public Integer getSetCount() {
		return setCount;
	}

	public void setSetCount(Integer setCount) {
		this.setCount = setCount;
	}

	public Integer getTheDelay() {
		return theDelay;
	}

	public void setTheDelay(Integer theDelay) {
		this.theDelay = theDelay;
	}

	public Integer getDelayDefault() {
		return delayDefault;
	}

	public void setDelayDefault(Integer delayDefault) {
		this.delayDefault = delayDefault;
	}
}
