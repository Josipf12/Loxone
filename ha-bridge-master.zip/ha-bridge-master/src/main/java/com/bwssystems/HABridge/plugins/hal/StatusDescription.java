package com.bwssystems.HABridge.plugins.hal;

public class StatusDescription {
	private String Status;
	private String Description;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
}
